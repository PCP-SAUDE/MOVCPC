-- Run this once if your unidades table doesn't have 'capacidade' column
ALTER TABLE unidades ADD COLUMN capacidade INT NULL DEFAULT NULL;
