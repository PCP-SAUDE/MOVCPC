<?php
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/auth.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save'])) {
    $id = intval($_POST['id'] ?? 0);
    $name = $_POST['name'] ?? ''; $email = $_POST['email'] ?? ''; $pass = $_POST['password'] ?? ''; $depart = $_POST['departamento'] ?? 'user';
    if ($id) {
        if ($pass) { $hash = password_hash($pass, PASSWORD_BCRYPT); $pdo->prepare('UPDATE users SET name=?,email=?,password=?,departamento=?,updated_at=NOW() WHERE id=?')->execute([$name,$email,$hash,$depart,$id]); }
        else { $pdo->prepare('UPDATE users SET name=?,email=?,departamento=?,updated_at=NOW() WHERE id=?')->execute([$name,$email,$depart,$id]); }
    } else {
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $pdo->prepare('INSERT INTO users (name,email,password,departamento,created_at,updated_at) VALUES (?,?,?,?,NOW(),NOW())')->execute([$name,$email,$hash,$depart]);
    }
    header('Location: /admin/usuarios.php'); exit;
}
if (isset($_GET['delete'])) { $id=intval($_GET['delete']); $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$id]); header('Location:/admin/usuarios.php'); exit; }

$users = $pdo->query('SELECT id,name,email,departamento,created_at FROM users')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Usuários</h1>
<a class="btn btn-sm btn-success mb-2" href="/admin/usuarios.php?action=new">Novo</a>
<?php if(isset($_GET['action']) && $_GET['action']=='new' || isset($_GET['action']) && $_GET['action']=='edit'):
    $form=['id'=>0,'name'=>'','email'=>'','departamento'=>'admin'];
    if (isset($_GET['action']) && $_GET['action']=='edit') { $id=intval($_GET['id']??0); $form = $pdo->prepare('SELECT * FROM users WHERE id=?')->execute([$id]) ? $pdo->query('SELECT * FROM users WHERE id='.intval($id))->fetch() : $form; }
?>
<form method="post"><input type="hidden" name="id" value="<?=htmlspecialchars($form['id'])?>">
<div class="mb-2"><label>Nome</label><input name="name" class="form-control" value="<?=htmlspecialchars($form['name'])?>" required></div>
<div class="mb-2"><label>Email</label><input name="email" class="form-control" value="<?=htmlspecialchars($form['email'])?>" required></div>
<div class="mb-2"><label>Senha</label><input name="password" class="form-control"></div>
<div class="mb-2"><label>Departamento (admin,diretor,comercial)</label><input name="departamento" class="form-control" value="<?=htmlspecialchars($form['departamento'])?>"></div>
<button name="save" class="btn btn-primary">Salvar</button></form>
<?php endif; ?>

<table class="table"><thead><tr><th>ID</th><th>Nome</th><th>Email</th><th>Depto</th><th>Criado</th><th>Ações</th></tr></thead><tbody>
<?php foreach($users as $us): ?><tr><td><?=intval($us['id'])?></td><td><?=htmlspecialchars($us['name'])?></td><td><?=htmlspecialchars($us['email'])?></td><td><?=htmlspecialchars($us['departamento'])?></td><td><?=htmlspecialchars($us['created_at'])?></td>
<td><a class="btn btn-sm btn-primary" href="/admin/usuarios.php?action=edit&id=<?=$us['id']?>">Editar</a> <a class="btn btn-sm btn-danger" href="/admin/usuarios.php?delete=<?=$us['id']?>" onclick="return confirm('Excluir?')">Excluir</a></td></tr><?php endforeach; ?>
</tbody></table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
