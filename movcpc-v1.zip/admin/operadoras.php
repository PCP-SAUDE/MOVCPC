<?php
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/auth.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save'])) {
    $id=intval($_POST['id']??0); $name = trim($_POST['operadora']??'');
    if ($id) { $pdo->prepare('UPDATE operadoras SET operadora=? WHERE id=?')->execute([$name,$id]); }
    else { $pdo->prepare('INSERT INTO operadoras (operadora) VALUES (?)')->execute([$name]); }
    header('Location:/admin/operadoras.php'); exit;
}
if (isset($_GET['del'])) { $pdo->prepare('DELETE FROM operadoras WHERE id=?')->execute([intval($_GET['del'])]); header('Location:/admin/operadoras.php'); exit; }

$ops = $pdo->query('SELECT * FROM operadoras ORDER BY operadora')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Operadoras</h1>
<a class="btn btn-sm btn-success mb-2" href="/admin/operadoras.php?action=new">Novo</a>
<?php if(isset($_GET['action']) && in_array($_GET['action'],['new','edit'])):
  $form=['id'=>0,'operadora'=>'']; if ($_GET['action']=='edit'){ $id=intval($_GET['id']??0); $form = $pdo->prepare('SELECT * FROM operadoras WHERE id=?')->execute([$id]) ? $pdo->query('SELECT * FROM operadoras WHERE id='.intval($id))->fetch() : $form; }
?>
<form method="post"><input type="hidden" name="id" value="<?=htmlspecialchars($form['id'])?>">
<div class="mb-2"><label>Operadora</label><input name="operadora" class="form-control" value="<?=htmlspecialchars($form['operadora'])?>" required></div>
<button name="save" class="btn btn-primary">Salvar</button></form>
<?php endif; ?>
<table class="table"><thead><tr><th>ID</th><th>Operadora</th><th>Ações</th></tr></thead><tbody>
<?php foreach($ops as $o): ?><tr><td><?=$o['id']?></td><td><?=htmlspecialchars($o['operadora'])?></td><td><a class="btn btn-sm btn-primary" href="/admin/operadoras.php?action=edit&id=<?=$o['id']?>">Editar</a> <a class="btn btn-sm btn-danger" href="/admin/operadoras.php?del=<?=$o['id']?>" onclick="return confirm('Excluir?')">Excluir</a></td></tr><?php endforeach; ?>
</tbody></table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
