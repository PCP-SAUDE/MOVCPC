<?php
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/auth.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save'])) {
    $id=intval($_POST['id']??0); $nome = trim($_POST['linha']??'');
    if ($id) { $pdo->prepare('UPDATE linha_cuidados SET linha=? WHERE id=?')->execute([$nome,$id]); }
    else { $pdo->prepare('INSERT INTO linha_cuidados (linha) VALUES (?)')->execute([$nome]); }
    header('Location:/admin/linha_cuidados.php'); exit;
}
if (isset($_GET['del'])) { $pdo->prepare('DELETE FROM linha_cuidados WHERE id=?')->execute([intval($_GET['del'])]); header('Location:/admin/linha_cuidados.php'); exit; }

$rows = $pdo->query('SELECT * FROM linha_cuidados ORDER BY id')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Linha de Cuidados</h1>
<a class="btn btn-sm btn-success mb-2" href="/admin/linha_cuidados.php?action=new">Novo</a>
<?php if(isset($_GET['action']) && in_array($_GET['action'],['new','edit'])):
  $form=['id'=>0,'linha'=>'']; if ($_GET['action']=='edit'){ $id=intval($_GET['id']??0); $form = $pdo->prepare('SELECT * FROM linha_cuidados WHERE id=?')->execute([$id]) ? $pdo->query('SELECT * FROM linha_cuidados WHERE id='.intval($id))->fetch() : $form; }
?>
<form method="post"><input type="hidden" name="id" value="<?=htmlspecialchars($form['id'])?>">
<div class="mb-2"><label>Nome</label><input name="linha" class="form-control" value="<?=htmlspecialchars($form['linha'])?>" required></div>
<button name="save" class="btn btn-primary">Salvar</button></form>
<?php endif; ?>
<table class="table"><thead><tr><th>ID</th><th>Nome</th><th>Ações</th></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?=$r['id']?></td><td><?=htmlspecialchars($r['linha'])?></td><td><a class="btn btn-sm btn-primary" href="/admin/linha_cuidados.php?action=edit&id=<?=$r['id']?>">Editar</a> <a class="btn btn-sm btn-danger" href="/admin/linha_cuidados.php?del=<?=$r['id']?>" onclick="return confirm('Excluir?')">Excluir</a></td></tr><?php endforeach; ?>
</tbody></table>
<?php include __DIR__ . '/../includes/footer.php'; ?>
