<?php
require_once __DIR__ . '/../lib/auth.php';
$u = user();
?>
<!doctype html><html><head><meta charset="utf-8"><title>MOVCPC</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="/dashboard.php">MOVCPC</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <?php if($u): ?>
          <li class="nav-item"><a class="nav-link" href="/pages/admissao.php">Admissão</a></li>
          <li class="nav-item"><a class="nav-link" href="/pages/pacientes.php">Pacientes</a></li>
          <li class="nav-item"><a class="nav-link" href="/pages/unidades.php">Unidades</a></li>
          <?php if($u['role']==='admin'): ?>
            <li class="nav-item"><a class="nav-link" href="/admin/usuarios.php">Usuários</a></li>
            <li class="nav-item"><a class="nav-link" href="/admin/operadoras.php">Operadoras</a></li>
            <li class="nav-item"><a class="nav-link" href="/admin/linha_cuidados.php">Linha Cuidados</a></li>
          <?php endif; ?>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav">
        <?php if($u): ?>
          <li class="nav-item"><span class="nav-link">Olá, <?=htmlspecialchars($u['name'])?></span></li>
          <li class="nav-item"><a class="nav-link" href="/logout.php">Sair</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="/index.php">Entrar</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container mt-4">
