<?php
$config = require __DIR__ . '/../config.php';
require __DIR__ . '/../lib/db.php';
$tipo = $_POST['tipo'] ?? '';
$paciente = $_POST['paciente'] ?? '';
$unidade = $_POST['unidade'] ?? '';
$leito = $_POST['leito'] ?? '';
$payload = ['tipo'=>$tipo,'paciente'=>$paciente,'unidade'=>$unidade,'leito'=>$leito,'received_at'=>date('c')];
try { $pdo->prepare('INSERT INTO notifications (payload, created_at) VALUES (?, NOW())')->execute([json_encode($payload)]); } catch(Exception $e) {}
if (!empty($config['whatsapp']['url'])) {
  $ch = curl_init($config['whatsapp']['url']);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ['token'=>$config['whatsapp']['token'],'message'=>json_encode($payload)]);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $resp = curl_exec($ch);
  curl_close($ch);
  header('Content-Type: application/json'); echo json_encode(['status'=>'forwarded','response'=>$resp]); exit;
}
header('Content-Type: application/json'); echo json_encode(['status'=>'stored','payload'=>$payload]);
