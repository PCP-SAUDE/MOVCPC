MOVCPC - Plain PHP system (tailored)

What I implemented:
- Admissao form aligned to your pacientes table (uses beds and operadoras)
- Pacientes page (read-only, filters)
- Dashboard showing occupancy per unidade using beds counts or unidades.capacidade if set
- Alta page (automatic date/time)
- Admin CRUDs: usuarios, operadoras, linha_cuidados, unidades (with capacity), beds management
- API endpoint /api/leitos.php to list beds by unidade for the admission form
- API webhook placeholder /api/notificacao.php

Setup:
1. Upload this folder to /var/www/movcpc
2. Edit config.php with DB credentials
3. If unidades.capacidade not present, run sql/add_capacidade_unidades.sql
4. Ensure ownership:
   sudo chown -R www-data:www-data /var/www/movcpc
   sudo chmod -R 755 /var/www/movcpc
5. Configure Nginx root to /var/www/movcpc and fastcgi_pass to your php-fpm socket
6. Restart services:
   sudo systemctl restart php8.3-fpm nginx

Notes:
- complexidade is a free-text field (no separate table provided)
- ops stores the operadora name (selected from operadoras table)
- id_user is set from the logged-in user's session
- webhook forwarding active only if you set whatsapp.url in config.php

