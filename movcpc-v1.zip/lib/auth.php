<?php
if (session_status() === PHP_SESSION_NONE) session_start();

function login($pdo, $email, $password) {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $u = $stmt->fetch();
    if (!$u) return false;
    if (password_verify($password, $u['password'] ?? '') || ($u['password'] === $password)) {
        $_SESSION['user_id'] = $u['id'];
        $_SESSION['user_name'] = $u['name'] ?? $u['email'];
        $_SESSION['user_role'] = strtolower($u['departamento'] ?? 'user');
        return true;
    }
    return false;
}

function check() { return isset($_SESSION['user_id']); }
function user() { if (!check()) return null; return ['id'=>$_SESSION['user_id'],'name'=>$_SESSION['user_name'],'role'=>$_SESSION['user_role']]; }
function require_login() { if (!check()) { header('Location: /index.php'); exit; } }
function require_role($roles=[]) { require_login(); $u=user(); if (!in_array($u['role'], (array)$roles)) { http_response_code(403); echo 'Forbidden'; exit; } }
