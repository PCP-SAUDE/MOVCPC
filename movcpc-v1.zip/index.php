<?php
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/auth.php';
$err='';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $pass = $_POST['password'] ?? '';
    if (login($pdo, $email, $pass)) {
        header('Location: /dashboard.php');
        exit;
    } else {
        $err = 'Credenciais inválidas';
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>MOVCPC - Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<div class="container py-5"><div class="row justify-content-center"><div class="col-md-4">
<div class="card shadow"><div class="card-body">
<h4 class="card-title mb-3">MOVCPC - Login</h4>
<?php if($err): ?><div class="alert alert-danger"><?=htmlspecialchars($err)?></div><?php endif; ?>
<form method="post">
<div class="mb-2"><label>Email</label><input name="email" class="form-control" required></div>
<div class="mb-2"><label>Senha</label><input name="password" type="password" class="form-control" required></div>
<button class="btn btn-primary w-100">Entrar</button>
</form>
</div></div>
<p class="text-center mt-3 text-muted small">Sistema simples — PHP + MySQL</p>
</div></div></div>
</body></html>
