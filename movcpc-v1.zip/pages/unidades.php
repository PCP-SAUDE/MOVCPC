<?php
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/auth.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_unit'])) {
    $id=intval($_POST['id']??0); $name = trim($_POST['unidade']??''); $cap = intval($_POST['capacidade']??0);
    if ($id) { $pdo->prepare('UPDATE unidades SET unidade=?, capacidade=? WHERE id=?')->execute([$name,$cap,$id]); }
    else { $pdo->prepare('INSERT INTO unidades (unidade, sigla, capacidade) VALUES (?,?,?)')->execute([$name,'',$cap]); }
    header('Location:/admin/unidades.php'); exit;
}
if (isset($_GET['del_unit'])) { $pdo->prepare('DELETE FROM unidades WHERE id=?')->execute([intval($_GET['del_unit'])]); header('Location:/admin/unidades.php'); exit; }

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add_bed'])) {
    $un = intval($_POST['unidade_id']??0); $num = trim($_POST['number']??'');
    if ($un && $num) $pdo->prepare('INSERT INTO beds (unidade_id, number, created_at, updated_at) VALUES (?,?,NOW(),NOW())')->execute([$un,$num]);
    header('Location:/admin/unidades.php?u='.$un); exit;
}
if (isset($_GET['del_bed'])) { $pdo->prepare('DELETE FROM beds WHERE id=?')->execute([intval($_GET['del_bed'])]); header('Location:/admin/unidades.php'); exit; }

$units = $pdo->query('SELECT * FROM unidades ORDER BY id')->fetchAll();
$beds = [];
if (isset($_GET['u'])) { $u=intval($_GET['u']); $beds = $pdo->prepare('SELECT * FROM beds WHERE unidade_id = ? ORDER BY number'); $beds->execute([$u]); $beds = $beds->fetchAll(); }

include __DIR__ . '/../includes/header.php';
?>
<h1>Unidades & Leitos</h1>
<h4>Nova Unidade</h4>
<form method="post" class="row g-2 mb-3"><input type="hidden" name="id" value="0">
<div class="col-auto"><input name="unidade" class="form-control" placeholder="Nome da unidade" required></div>
<div class="col-auto"><input name="capacidade" class="form-control" placeholder="Capacidade (opcional)"></div>
<div class="col-auto"><button name="save_unit" class="btn btn-primary">Criar</button></div></form>

<div class="row">
  <div class="col-md-5">
    <h5>Unidades</h5>
    <ul class="list-group">
      <?php foreach($units as $un): ?><li class="list-group-item d-flex justify-content-between align-items-center">
        <a href="/admin/unidades.php?u=<?=$un['id']?>"><?=htmlspecialchars($un['unidade'])?></a><span class="badge bg-secondary"><?=intval($pdo->prepare('SELECT COUNT(*) FROM beds WHERE unidade_id=?')->execute([$un['id']]) ? '' : '')?></span></li><?php endforeach; ?>
    </ul>
  </div>
  <div class="col-md-7">
    <?php if(isset($_GET['u'])): ?>
      <h5>Leitos da unidade</h5>
      <form method="post" class="row g-2 mb-3"><input type="hidden" name="unidade_id" value="<?=intval($_GET['u'])?>">
        <div class="col-auto"><input name="number" class="form-control" placeholder="Número do leito" required></div>
        <div class="col-auto"><button name="add_bed" class="btn btn-primary">Adicionar leito</button></div></form>
      <table class="table"><thead><tr><th>ID</th><th>Número</th><th>Ações</th></tr></thead><tbody>
      <?php foreach($beds as $b): ?><tr><td><?=intval($b['id'])?></td><td><?=htmlspecialchars($b['number'])?></td><td><a class="btn btn-sm btn-danger" href="/admin/unidades.php?del_bed=<?=$b['id']?>" onclick="return confirm('Excluir?')">Excluir</a></td></tr><?php endforeach; ?>
      </tbody></table>
    <?php else: ?><p>Selecione uma unidade.</p><?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
