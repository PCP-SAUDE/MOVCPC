<?php
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/auth.php';
require_login();

$q = [];
$where = [];

if (!empty($_GET['nome'])) { $where[] = 'nome LIKE ?'; $q[] = '%'.$_GET['nome'].'%'; }
if (!empty($_GET['unidade'])) { $where[] = 'unidade = ?'; $q[] = $_GET['unidade']; }
if (!empty($_GET['leito'])) { $where[] = 'leito = ?'; $q[] = $_GET['leito']; }
if (!empty($_GET['ops'])) { $where[] = 'ops = ?'; $q[] = $_GET['ops']; }
if (!empty($_GET['status'])) { $where[] = 'status = ?'; $q[] = $_GET['status']; }

$sql = 'SELECT * FROM pacientes';
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' ORDER BY created_at DESC LIMIT 500';
$stmt = $pdo->prepare($sql);
$stmt->execute($q);
$pacientes = $stmt->fetchAll();

$unidades = $pdo->query('SELECT id, unidade FROM unidades')->fetchAll();
$operadoras = $pdo->query('SELECT operadora FROM operadoras')->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<h1>Pacientes (consulta)</h1>
<form class="row g-2 mb-3" method="get">
  <div class="col-md-3"><input name="nome" class="form-control" placeholder="Nome" value="<?=htmlspecialchars($_GET['nome']??'')?>"></div>
  <div class="col-md-3">
    <select name="unidade" class="form-select">
      <option value="">Unidade</option>
      <?php foreach($unidades as $u): ?><option value="<?=intval($u['id'])?>" <?=((isset($_GET['unidade']) && $_GET['unidade']==$u['id'])?'selected':'')?>><?=htmlspecialchars($u['unidade'])?></option><?php endforeach; ?>
    </select>
  </div>
  <div class="col-md-2"><input name="leito" class="form-control" placeholder="Leito" value="<?=htmlspecialchars($_GET['leito']??'')?>"></div>
  <div class="col-md-2"><input name="ops" class="form-control" placeholder="Operadora" value="<?=htmlspecialchars($_GET['ops']??'')?>"></div>
  <div class="col-md-2"><select name="status" class="form-select"><option value=''>Status</option><option value='Internado'>Internado</option><option value='Alta'>Alta</option><option value='Óbito'>Óbito</option></select></div>
  <div class="col-md-12"><button class="btn btn-secondary mt-2">Filtrar</button></div>
</form>

<table class="table table-striped">
<thead><tr><th>ID</th><th>Nome</th><th>Unidade</th><th>Leito</th><th>Operadora</th><th>Status</th><th>Entrada</th></tr></thead>
<tbody>
<?php foreach($pacientes as $p): ?>
<tr>
  <td><?=intval($p['id'])?></td>
  <td><?=htmlspecialchars($p['nome'])?></td>
  <td><?=htmlspecialchars($p['unidade'])?></td>
  <td><?=htmlspecialchars($p['leito'])?></td>
  <td><?=htmlspecialchars($p['ops'])?></td>
  <td><?=htmlspecialchars($p['status'])?></td>
  <td><?=htmlspecialchars($p['dataIntern'].' '.$p['horaIntern'])?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>
