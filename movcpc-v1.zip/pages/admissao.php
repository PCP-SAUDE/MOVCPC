<?php
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/auth.php';
require_login();
$u = user();

// load selects
$operadoras = $pdo->query('SELECT id, operadora FROM operadoras ORDER BY operadora')->fetchAll();
$linhas = $pdo->query('SELECT id, linha FROM linha_cuidados ORDER BY id')->fetchAll();
$unidades = $pdo->query('SELECT id, unidade FROM unidades ORDER BY id')->fetchAll();

$err=''; $success='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $nome = trim($_POST['nome'] ?? '');
    $dataNasc = $_POST['dataNasc'] ?? null;
    $idade = intval($_POST['idade'] ?? 0);
    $hospitalOrig = trim($_POST['hospitalOrig'] ?? '');
    $ops_id = $_POST['ops'] ?? '';
    $ops_name = '';
    if ($ops_id) {
        $stmt = $pdo->prepare('SELECT operadora FROM operadoras WHERE id = ? LIMIT 1'); $stmt->execute([$ops_id]);
        $row = $stmt->fetch(); $ops_name = $row ? $row['operadora'] : '';
    }
    $ops = $ops_name;
    $hd = trim($_POST['hd'] ?? '');
    $complexidade = trim($_POST['complexidade'] ?? '');
    $linhaCuidados = $_POST['linhaCuidados'] ?? '';
    $unidade = $_POST['unidade'] ?? '';
    $leito = $_POST['leito'] ?? '';
    $acompanhante = trim($_POST['acompanhante'] ?? '');
    $necessidadeEspecial = trim($_POST['necessidadeEspecial'] ?? '');
    $descricaoEspecial = trim($_POST['descricaoEspecial'] ?? '');

    if ($nome==='' || $ops==='' || $complexidade==='' || $linhaCuidados==='' || $unidade==='' || $leito==='') {
        $err = 'Preencha todos os campos obrigatórios.';
    } else {
        // check leito occupancy
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM pacientes WHERE unidade = ? AND leito = ? AND status = ?');
        $stmt->execute([$unidade, $leito, 'Internado']);
        if ($stmt->fetchColumn() > 0) {
            $err = 'Leito já ocupado.';
        } else {
            // insert paciente
            $ins = $pdo->prepare('INSERT INTO pacientes (id_user, nome, dataNasc, idade, hospitalOrig, ops, hd, complexidade, linhaCuidados, unidade, leito, dataIntern, horaIntern, acompanhante, necessidadeEspecial, descricaoEspecial, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())');
            $nowDate = date('Y-m-d'); $nowTime = date('H:i:s');
            $ins->execute([$u['id'],$nome,$dataNasc,$idade,$hospitalOrig,$ops,$hd,$complexidade,$linhaCuidados,$unidade,$leito,$nowDate,$nowTime,$acompanhante,$necessidadeEspecial,$descricaoEspecial,'Internado']);
            $success = 'Paciente internado com sucesso.';
            // notify webhook (non-blocking)
            $payload = http_build_query(['tipo'=>'admissao','paciente'=>$nome,'unidade'=>$unidade,'leito'=>$leito]);
            $ch = curl_init(); curl_setopt($ch, CURLOPT_URL, '/api/notificacao.php'); curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $payload); curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); curl_setopt($ch, CURLOPT_TIMEOUT_MS, 200); @curl_exec($ch); curl_close($ch);
        }
    }
}

include __DIR__ . '/../includes/header.php';
?>
<h1>Admissão de Paciente</h1>
<?php if($err): ?><div class="alert alert-danger"><?=htmlspecialchars($err)?></div><?php endif; ?>
<?php if($success): ?><div class="alert alert-success"><?=htmlspecialchars($success)?></div><?php endif; ?>

<form method="post">
  <div class="row mb-2">
    <div class="col-md-8"><label>Nome*</label><input name="nome" class="form-control" required></div>
    <div class="col-md-4"><label>Data Nasc</label><input name="dataNasc" type="date" class="form-control"></div>
  </div>
  <div class="row mb-2">
    <div class="col-md-2"><label>Idade</label><input name="idade" type="number" class="form-control"></div>
    <div class="col-md-4"><label>Hospital Origem</label><input name="hospitalOrig" class="form-control"></div>
    <div class="col-md-6"><label>Operadora (OPS)*</label>
      <select name="ops" class="form-select" required>
        <option value="">-- selecione --</option>
        <?php foreach($operadoras as $o): ?>
          <option value="<?=intval($o['id'])?>"><?=htmlspecialchars($o['operadora'])?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <div class="row mb-2">
    <div class="col-md-4"><label>HD</label><input name="hd" class="form-control"></div>
    <div class="col-md-4"><label>Complexidade*</label><input name="complexidade" class="form-control" required></div>
    <div class="col-md-4"><label>Linha de Cuidados*</label>
      <select name="linhaCuidados" class="form-select" required>
        <option value="">-- selecione --</option>
        <?php foreach($linhas as $l): ?>
          <option value="<?=htmlspecialchars($l['id'])?>"><?=htmlspecialchars($l['nome'])?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>

  <div class="row mb-2">
    <div class="col-md-6"><label>Unidade*</label>
      <select id="unidade" name="unidade" class="form-select" required onchange="fetchLeitos(this.value)">
        <option value="">-- selecione --</option>
        <?php foreach($unidades as $un): ?>
          <option value="<?=intval($un['id'])?>"><?=htmlspecialchars($un['unidade'])?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-6"><label>Leito*</label>
      <select id="leito" name="leito" class="form-select" required><option value="">-- selecione unidade --</option></select>
    </div>
  </div>

  <div class="mb-2"><label>Acompanhante</label><input name="acompanhante" class="form-control"></div>
  <div class="mb-2"><label>Necessidade Especial</label><input name="necessidadeEspecial" class="form-control"></div>
  <div class="mb-2"><label>Descrição Especial</label><input name="descricaoEspecial" class="form-control"></div>

  <button class="btn btn-primary">Internar</button>
</form>

<script>
function fetchLeitos(unidadeId){
  var sel = document.getElementById('leito');
  sel.innerHTML = '<option>Carregando...</option>';
  fetch('/api/leitos.php?unidade_id='+encodeURIComponent(unidadeId))
    .then(r=>r.json()).then(data=>{
      sel.innerHTML = '<option value="">-- selecione --</option>';
      data.forEach(function(it){
        var opt = document.createElement('option');
        opt.value = it.number;
        opt.text = it.number;
        sel.appendChild(opt);
      });
    }).catch(e=>{
      sel.innerHTML = '<option value="">Erro ao carregar</option>';
    });
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
