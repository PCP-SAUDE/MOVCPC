<?php
return [ 'db'=>['host'=>'127.0.0.1','port'=>3306,'name'=>'movcpc','user'=>'movcpc_user','pass'=>'SUA_SENHA_AQUI','charset'=>'utf8mb4'], 'whatsapp'=>['url'=>'','token'=>''] ];
