<?php
require __DIR__ . '/../lib/db.php'; require __DIR__ . '/../lib/auth.php'; require_login();
$err=''; $success='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $paciente_id = intval($_POST['paciente_id'] ?? 0); $motivo = $_POST['motivo'] ?? 'Alta';
    if (!$paciente_id) $err='Paciente inválido'; else {
        $stmt=$pdo->prepare('SELECT * FROM pacientes WHERE id=?'); $stmt->execute([$paciente_id]); $p=$stmt->fetch();
        if (!$p) $err='Paciente não encontrado'; else {
            $nowDate = date('Y-m-d'); $nowTime = date('H:i:s');
            $pdo->prepare('UPDATE pacientes SET status=?, dataSaida=?, horaSaida=?, justificativa=?, updated_at = NOW() WHERE id=?')->execute([$motivo,$nowDate,$nowTime,$motivo,$paciente_id]);
            $success='Saída registrada.';
            $payload = http_build_query(['tipo'=>'saida','paciente'=>$p['nome'],'unidade'=>$p['unidade'],'leito'=>$p['leito'],'motivo'=>$motivo]);
            $ch = curl_init(); curl_setopt($ch, CURLOPT_URL, '/api/notificacao.php'); curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $payload); curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); curl_setopt($ch, CURLOPT_TIMEOUT_MS, 200); @curl_exec($ch); curl_close($ch);
        }
    }
}
$internados = $pdo->query("SELECT id, nome, unidade, leito FROM pacientes WHERE status = 'Internado' ORDER BY unidade, leito")->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Registrar Alta / Óbito</h1>
<?php if($err): ?><div class="alert alert-danger"><?=htmlspecialchars($err)?></div><?php endif; ?>
<?php if($success): ?><div class="alert alert-success"><?=htmlspecialchars($success)?></div><?php endif; ?>
<form method="post"><div class="mb-3"><label>Paciente</label><select name="paciente_id" class="form-select" required><option value=''>-- selecione --</option><?php foreach($internados as $p): ?><option value='<?=intval($p['id'])?>'><?=htmlspecialchars($p['nome'])?> — Unidade <?=htmlspecialchars($p['unidade'])?> / Leito <?=htmlspecialchars($p['leito'])?></option><?php endforeach; ?></select></div>
<div class="mb-3"><label>Motivo</label><select name="motivo" class="form-select"><option>Alta</option><option>Óbito</option><option>Transferência</option></select></div>
<button class="btn btn-danger">Registrar Saída</button></form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
