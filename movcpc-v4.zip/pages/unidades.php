<?php
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/auth.php';
require_login();

$units = $pdo->query("SELECT id, unidade, capacidade FROM unidades ORDER BY unidade")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="container mt-3">
    <h3>Unidades</h3>

    <div class="row row-cols-1 row-cols-md-2 g-3">
    <?php foreach ($units as $u): ?>
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h5><?= $u['unidade'] ?></h5>
                    <p>Capacidade: <?= $u['capacidade'] ?></p>
                    <a href="/pages/leitos.php?u=<?= $u['id'] ?>" class="btn btn-sm btn-primary">Ver Leitos</a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
