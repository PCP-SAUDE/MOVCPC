<?php
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/auth.php';
require_login();

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome    = $_POST['nome'];
    $idade   = $_POST['idade'];
    $unidade = $_POST['unidade'];
    $leito   = $_POST['leito'];
    $ops     = $_POST['ops'];
    $status  = $_POST['status'];

    $ins = $pdo->prepare("INSERT INTO pacientes (nome, idade, unidade, leito, ops, status, dataEntrada, horaEntrada)
                          VALUES (?, ?, ?, ?, ?, ?, CURDATE(), CURTIME())");
    $ins->execute([$nome, $idade, $unidade, $leito, $ops, $status]);

    // buscar nome da unidade
    $u = $pdo->prepare("SELECT unidade FROM unidades WHERE id=? LIMIT 1");
    $u->execute([$unidade]);
    $uRow = $u->fetch();
    $unidadeNome = $uRow ? $uRow['unidade'] : $unidade;

    // enviar notificação
    $notify = [
        'tipo'     => 'Admissão',
        'paciente' => $nome,
        'unidade'  => $unidadeNome,
        'leito'    => $leito
    ];

    $ch = curl_init("/api/notificacao.php");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $notify);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT_MS, 200);
    @curl_exec($ch);
    curl_close($ch);

    $success = "Paciente admitido com sucesso!";
}

// listas
$unidades = $pdo->query("SELECT id, unidade FROM unidades ORDER BY unidade")->fetchAll();
$ops = $pdo->query("SELECT id, operadora FROM operadoras ORDER BY operadora")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="container mt-3">
    <h3>Admissão de Paciente</h3>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST">

        <div class="mb-3">
            <label>Nome</label>
            <input class="form-control" name="nome" required>
        </div>

        <div class="mb-3">
            <label>Idade</label>
            <input class="form-control" name="idade" type="number" required>
        </div>

        <div class="mb-3">
            <label>Unidade</label>
            <select name="unidade" class="form-control" required>
                <?php foreach ($unidades as $u): ?>
                    <option value="<?= $u['id'] ?>"><?= $u['unidade'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Leito</label>
            <input class="form-control" name="leito" required>
        </div>

        <div class="mb-3">
            <label>Operadora</label>
            <select name="ops" class="form-control" required>
                <?php foreach ($ops as $o): ?>
                    <option value="<?= $o['id'] ?>"><?= $o['operadora'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-control" required>
                <option value="Internado">Internado</option>
                <option value="Alta">Alta</option>
                <option value="Óbito">Óbito</option>
            </select>
        </div>

        <button class="btn btn-primary">Registrar</button>
    </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
