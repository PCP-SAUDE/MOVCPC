<?php
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/auth.php';
require_login();

$success = $error = "";

// atualizar
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $nome    = $_POST['nome'];
        $idade   = $_POST['idade'];
        $unidade = $_POST['unidade'];
        $leito   = $_POST['leito'];
        $ops     = $_POST['ops'];
        $status  = $_POST['status'];

        if ($status !== 'Internado') {
            $upd = $pdo->prepare("UPDATE pacientes SET nome=?,idade=?,unidade=?,leito=?,ops=?,status=?,dataSaida=CURDATE(),horaSaida=CURTIME(),updated_at=NOW() WHERE id=?");
            $upd->execute([$nome,$idade,$unidade,$leito,$ops,$status,$id]);
        } else {
            $upd = $pdo->prepare("UPDATE pacientes SET nome=?,idade=?,unidade=?,leito=?,ops=?,status=?,updated_at=NOW() WHERE id=?");
            $upd->execute([$nome,$idade,$unidade,$leito,$ops,$status,$id]);
        }

        $success = "Paciente atualizado.";
    }

    $p = $pdo->prepare("SELECT * FROM pacientes WHERE id=? LIMIT 1");
    $p->execute([$id]);
    $paciente = $p->fetch();
}

// listas
$lista = $pdo->query("SELECT p.*, u.unidade AS unidade_nome, o.operadora FROM pacientes p 
                      LEFT JOIN unidades u ON u.id = p.unidade
                      LEFT JOIN operadoras o ON o.id = p.ops
                      ORDER BY p.id DESC")->fetchAll();

$unidades = $pdo->query("SELECT * FROM unidades ORDER BY unidade")->fetchAll();
$ops = $pdo->query("SELECT * FROM operadoras ORDER BY operadora")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="container mt-3">
    <h3>Pacientes</h3>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <?php if (isset($paciente)): ?>
        <h5>Editar Paciente</h5>
        <form method="POST">
            <div class="mb-2">
                <label>Nome</label>
                <input class="form-control" name="nome" value="<?= $paciente['nome'] ?>">
            </div>

            <div class="mb-2">
                <label>Idade</label>
                <input class="form-control" type="number" name="idade" value="<?= $paciente['idade'] ?>">
            </div>

            <div class="mb-2">
                <label>Unidade</label>
                <select class="form-control" name="unidade">
                    <?php foreach ($unidades as $u): ?>
                        <option value="<?= $u['id'] ?>" <?= $u['id']==$paciente['unidade']?'selected':'' ?>>
                            <?= $u['unidade'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-2">
                <label>Leito</label>
                <input class="form-control" name="leito" value="<?= $paciente['leito'] ?>">
            </div>

            <div class="mb-2">
                <label>Operadora</label>
                <select class="form-control" name="ops">
                    <?php foreach ($ops as $o): ?>
                        <option value="<?= $o['id'] ?>" <?= $o['id']==$paciente['ops']?'selected':'' ?>>
                            <?= $o['operadora'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-2">
                <label>Status</label>
                <select class="form-control" name="status">
                    <option <?= $paciente['status']=='Internado'?'selected':'' ?>>Internado</option>
                    <option <?= $paciente['status']=='Alta'?'selected':'' ?>>Alta</option>
                    <option <?= $paciente['status']=='Óbito'?'selected':'' ?>>Óbito</option>
                </select>
            </div>

            <button class="btn btn-primary">Salvar</button>
        </form>
        <hr>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nome</th><th>Idade</th><th>Unidade</th><th>Leito</th><th>Operadora</th><th>Status</th><th>Ação</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($lista as $p): ?>
                <tr>
                    <td><?= $p['nome'] ?></td>
                    <td><?= $p['idade'] ?></td>
                    <td><?= $p['unidade_nome'] ?></td>
                    <td><?= $p['leito'] ?></td>
                    <td><?= $p['operadora'] ?></td>
                    <td><?= $p['status'] ?></td>
                    <td>
                        <a class="btn btn-sm btn-primary" href="?edit=<?= $p['id'] ?>">Editar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
