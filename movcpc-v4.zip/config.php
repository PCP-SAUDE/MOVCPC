<?php
// edit these to match your MySQL credentials
return [
  'db' => [
    'host'=>'127.0.0.1',
    'port'=>3306,
    'name'=>'movcpc',
    'user'=>'movcpc',
    'pass'=>'redealtana158',
    'charset'=>'utf8mb4'
  ],
  'whatsapp'=>[
    'url'=>'https://waha.pcpsaude.com.br/api/sendMessage',
    'token'=>'7BA040A510E4E66ED3743EC1B8F25A8A73EACF41'
  ],
  // group id where messages will be sent
  'whatsapp_group_id' => '120363403955396656@g.us'
];