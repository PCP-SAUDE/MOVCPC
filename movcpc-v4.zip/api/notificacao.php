<?php
$config = require __DIR__ . '/../config.php';
require __DIR__ . '/../lib/db.php';

$tipo = $_POST['tipo'] ?? '';
$paciente = $_POST['paciente'] ?? '';
$unidade = $_POST['unidade'] ?? '';
$leito = $_POST['leito'] ?? '';

$msg = "📢 *Movimentação de Paciente*\n";
if ($tipo)     $msg .= "*Tipo:* $tipo\n";
if ($paciente) $msg .= "*Paciente:* $paciente\n";
if ($unidade)  $msg .= "*Unidade:* $unidade\n";
if ($leito)    $msg .= "*Leito:* $leito\n";
$msg .= "\n🕒 " . date('Y-m-d H:i:s');

// WAHA payload
$payload = [
    'chatId'  => $config['whatsapp_group_id'],
    'message' => $msg
];

$ch = curl_init($config['whatsapp']['url']);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $config['whatsapp']['token']
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// salva tentativa (opcional)
try {
    $stmt = $pdo->prepare("INSERT INTO notifications (payload, created_at) VALUES (?, NOW())");
    $stmt->execute([json_encode(['payload'=>$payload,'response'=>$response,'code'=>$httpcode])]);
} catch(Exception $e){ }

echo json_encode(['sent'=>true,'http_code'=>$httpcode,'response'=>$response]);
