<?php require __DIR__ . '/../lib/db.php'; 
    $unidade = $_GET['unidade_id'] ?? ''; if (!$unidade) { echo json_encode([]); exit; } 
    $stmt = $pdo->prepare('SELECT number FROM beds WHERE unidade_id = ? ORDER BY number'); 
    $stmt->execute([$unidade]); 
    echo json_encode($stmt->fetchAll()); 