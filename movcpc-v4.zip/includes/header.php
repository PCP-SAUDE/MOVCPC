<?php
require_once __DIR__ . '/../lib/auth.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>MOVCPC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        .navbar-logo img {
            height: 32px;
            width: auto;
            filter: drop-shadow(0 0 3px rgba(0,0,0,0.4)); /* melhora visual em tema escuro */
        }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-dark px-3">
    <a class="navbar-brand navbar-logo d-flex align-items-center" href="/dashboard.php">
        <img src="https://redealtana.com.br/wp-content/uploads/2023/03/logo-altana-branca-1.svg">
    </a>

    <div>
        <a href="/dashboard.php" class="btn btn-outline-light btn-sm me-2">Dashboard</a>
        <a href="/pages/pacientes.php" class="btn btn-outline-light btn-sm me-2">Pacientes</a>
        <a href="/pages/admissao.php" class="btn btn-outline-light btn-sm me-2">Admissão</a>
        <a href="/pages/unidades.php" class="btn btn-outline-light btn-sm me-2">Unidades</a>
        <a href="/logout.php" class="btn btn-danger btn-sm">Sair</a>
    </div>
</nav>

<div class="container-fluid mt-3">
