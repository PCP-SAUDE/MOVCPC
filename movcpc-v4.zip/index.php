<?php
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (login($pdo, $_POST['email'], $_POST['password'])) {
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Credenciais inválidas.";
    }
}

include __DIR__ . '/includes/header.php';
?>
<div class="container mt-5" style="max-width:400px">
    <div class="card">
        <div class="card-body">
            <h4 class="mb-3">Login</h4>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label>Email</label>
                    <input class="form-control" name="email" required>
                </div>
                <div class="mb-3">
                    <label>Senha</label>
                    <input class="form-control" type="password" name="password" required>
                </div>

                <button class="btn btn-primary w-100">Entrar</button>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
