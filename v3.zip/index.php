<?php require __DIR__ . '/lib/db.php'; require __DIR__ . '/lib/auth.php';
$err=''; if($_SERVER['REQUEST_METHOD']==='POST'){ if(login($pdo,$_POST['email']??'',$_POST['password']??'')){ header('Location:/dashboard.php'); exit;} else $err='Credenciais inválidas'; }
?><!doctype html><html><head><meta charset="utf-8"><title>Login</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"></head><body class="bg-light">
<div class="container py-5"><div class="row justify-content-center"><div class="col-md-4">
<div class="card"><div class="card-body"><h4>MOVCPC - Login</h4><?php if($err):?><div class="alert alert-danger"><?=htmlspecialchars($err)?></div><?php endif; ?>
<form method="post"><input name="email" class="form-control mb-2" placeholder="email"><input name="password" type="password" class="form-control mb-2" placeholder="senha"><button class="btn btn-primary w-100">Entrar</button></form>
</div></div></div></div></div></body></html>
