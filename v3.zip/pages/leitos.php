<?php
require __DIR__ . '/../lib/db.php'; require __DIR__ . '/../lib/auth.php'; require_login();
$u = user();
$unidades = $pdo->query('SELECT id, unidade FROM unidades ORDER BY unidade')->fetchAll();
$selected = intval($_GET['u'] ?? 0);
$beds = [];
if ($selected) {
    $stmt = $pdo->prepare('SELECT b.id, b.number, (SELECT p.id FROM pacientes p WHERE p.unidade = b.unidade_id AND p.leito = b.number AND p.status = ? LIMIT 1) AS paciente_id FROM beds b WHERE b.unidade_id = ? ORDER BY b.number');
    $stmt->execute(['Internado', $selected]);
    $beds = $stmt->fetchAll();
    $patient_ids = array_filter(array_column($beds, 'paciente_id'));
    $patients = [];
    if ($patient_ids) {
        $in = implode(',', array_map('intval',$patient_ids));
        $rows = $pdo->query('SELECT id, nome FROM pacientes WHERE id IN ('.$in.')')->fetchAll();
        foreach($rows as $r) $patients[$r['id']] = $r['nome'];
    }
}
include __DIR__ . '/../includes/header.php';
?>
<h1>Leitos</h1>
<form class="row mb-3"><div class="col-md-4"><select onchange="location.href='?u='+this.value" class="form-select"><?php foreach($unidades as $un): ?><option value="<?=intval($un['id'])?>" <?=($selected==$un['id']?'selected':'')?>><?=htmlspecialchars($un['unidade'])?></option><?php endforeach; ?></select></div></form>
<?php if($selected): ?>
<table class="table"><thead><tr><th>ID</th><th>Leito</th><th>Status</th><th>Paciente</th></tr></thead><tbody>
<?php foreach($beds as $b): $pid = $b['paciente_id']; $ocup = $pid ? true : false; ?>
<tr><td><?=intval($b['id'])?></td><td><?=htmlspecialchars($b['number'])?></td><td><?php if($ocup): ?><span class="badge bg-danger">Ocupado</span><?php else: ?><span class="badge bg-success">Livre</span><?php endif; ?></td>
<td><?php if($ocup): ?><a href="/pages/pacientes.php?action=edit&id=<?=intval($pid)?>"><?=htmlspecialchars($patients[$pid]??'--')?></a><?php else: ?>-<?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table>
<?php else: ?><p>Selecione uma unidade para ver leitos.</p><?php endif; include __DIR__ . '/../includes/footer.php'; ?>
