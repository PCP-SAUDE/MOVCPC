<?php
require __DIR__ . '/../lib/db.php'; require __DIR__ . '/../lib/auth.php'; require_login();
$u = user();
$can_edit = in_array($u['role'], ['admin','comercial']);
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save']) && $can_edit) {
    $id = intval($_POST['id'] ?? 0);
    $nome = trim($_POST['nome'] ?? ''); $idade = intval($_POST['idade']??0);
    $unidade = intval($_POST['unidade']??0); $leito = trim($_POST['leito']??'');
    $ops = trim($_POST['ops'] ?? ''); $status = trim($_POST['status']??'Internado');
    if ($id) {
        if ($status !== 'Internado') { $nowDate = date('Y-m-d'); $nowTime = date('H:i:s'); $pdo->prepare('UPDATE pacientes SET nome=?,idade=?,unidade=?,leito=?,ops=?,status=?,dataSaida=?,horaSaida=?,updated_at=NOW() WHERE id=?')->execute([$nome,$idade,$unidade,$leito,$ops,$status,$nowDate,$nowTime,$id]); }
        else { $pdo->prepare('UPDATE pacientes SET nome=?,idade=?,unidade=?,leito=?,ops=?,status=?,updated_at=NOW() WHERE id=?')->execute([$nome,$idade,$unidade,$leito,$ops,$status,$id]); }
    }
    header('Location:/pages/pacientes.php'); exit;
}
$where=[]; $params=[];
if (!empty($_GET['nome'])) { $where[]='p.nome LIKE ?'; $params[]='%'.$_GET['nome'].'%'; }
if (!empty($_GET['unidade'])) { $where[]='p.unidade = ?'; $params[]=intval($_GET['unidade']); }
if (!empty($_GET['leito'])) { $where[]='p.leito = ?'; $params[]=$_GET['leito']; }
if (!empty($_GET['ops'])) { $where[]='p.ops = ?'; $params[]=$_GET['ops']; }
if (!empty($_GET['status'])) { $where[]='p.status = ?'; $params[]=$_GET['status']; }
$sql = 'SELECT p.*, u.unidade AS unidade_nome FROM pacientes p LEFT JOIN unidades u ON p.unidade = u.id' . ($where ? ' WHERE '.implode(' AND ', $where) : '') . ' ORDER BY p.created_at DESC LIMIT 500';
$stmt = $pdo->prepare($sql); $stmt->execute($params); $pacientes = $stmt->fetchAll();
$unidades = $pdo->query('SELECT id, unidade FROM unidades')->fetchAll();
include __DIR__ . '/../includes/header.php';
?>
<h1>Pacientes</h1>
<form class="row g-2 mb-3" method="get">
  <div class="col-md-3"><input name="nome" class="form-control" placeholder="Nome" value="<?=htmlspecialchars($_GET['nome']??'')?>"></div>
  <div class="col-md-3"><select name="unidade" class="form-select"><option value=''>Unidade</option><?php foreach($unidades as $un): ?><option value='<?=intval($un['id'])?>' <?=((isset($_GET['unidade']) && $_GET['unidade']==$un['id'])?'selected':'')?>><?=htmlspecialchars($un['unidade'])?></option><?php endforeach; ?></select></div>
  <div class="col-md-2"><input name="leito" class="form-control" placeholder="Leito" value="<?=htmlspecialchars($_GET['leito']??'')?>"></div>
  <div class="col-md-2"><input name="ops" class="form-control" placeholder="Operadora" value="<?=htmlspecialchars($_GET['ops']??'')?>"></div>
  <div class="col-md-2"><select name="status" class="form-select"><option value=''>Status</option><option value='Internado'>Internado</option><option value='Alta'>Alta</option><option value='Óbito'>Óbito</option></select></div>
  <div class="col-md-12"><button class="btn btn-secondary mt-2">Filtrar</button></div>
</form>

<table class="table table-striped"><thead><tr><th>ID</th><th>Nome</th><th>Unidade</th><th>Leito</th><th>Operadora</th><th>Status</th><th>Entrada</th><th>Ações</th></tr></thead><tbody>
<?php foreach($pacientes as $p): ?>
<tr><td><?=intval($p['id'])?></td><td><?=htmlspecialchars($p['nome'])?></td><td><?=htmlspecialchars($p['unidade_nome']??$p['unidade'])?></td><td><?=htmlspecialchars($p['leito'])?></td><td><?=htmlspecialchars($p['ops'])?></td><td><?=htmlspecialchars($p['status'])?></td><td><?=htmlspecialchars($p['dataIntern'].' '.$p['horaIntern'])?></td>
<td><?php if($can_edit): ?><a class="btn btn-sm btn-primary" href="/pages/pacientes.php?action=edit&id=<?=$p['id']?>">Editar</a><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table>

<?php if(isset($_GET['action']) && $_GET['action']=='edit' && $can_edit):
    $id=intval($_GET['id']??0);
    $stmt=$pdo->prepare('SELECT * FROM pacientes WHERE id=?'); $stmt->execute([$id]); $form=$stmt->fetch();
    if(!$form) { echo '<div class="alert alert-danger">Paciente não encontrado</div>'; include __DIR__.'/../includes/footer.php'; exit; }
?>
<hr><h3>Editar Paciente #<?=intval($form['id'])?></h3>
<form method="post"><input type="hidden" name="id" value="<?=intval($form['id'])?>">
<div class="mb-2"><label>Nome</label><input name="nome" class="form-control" value="<?=htmlspecialchars($form['nome'])?>"></div>
<div class="mb-2"><label>Idade</label><input name="idade" class="form-control" value="<?=intval($form['idade'])?>"></div>
<div class="mb-2"><label>Operadora</label><input name="ops" class="form-control" value="<?=htmlspecialchars($form['ops'])?>"></div>
<div class="row"><div class="col-md-6"><label>Unidade</label><select name="unidade" class="form-select"><?php foreach($unidades as $un): ?><option value='<?=intval($un['id'])?>' <?=($form['unidade']==$un['id']?'selected':'')?>><?=htmlspecialchars($un['unidade'])?></option><?php endforeach; ?></select></div>
<div class="col-md-6"><label>Leito</label><input name="leito" class="form-control" value="<?=htmlspecialchars($form['leito'])?>"></div></div>
<div class="mb-2"><label>Status</label><select name="status" class="form-select"><option value='Internado' <?=($form['status']=='Internado'?'selected':'')?>>Internado</option><option value='Alta' <?=($form['status']=='Alta'?'selected':'')?>>Alta</option><option value='Óbito' <?=($form['status']=='Óbito'?'selected':'')?>>Óbito</option></select></div>
<button name="save" class="btn btn-primary">Salvar</button></form>
<?php endif; include __DIR__ . '/../includes/footer.php'; ?>
