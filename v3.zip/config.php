<?php
// edit these to match your MySQL credentials
return [
  'db' => [
    'host'=>'127.0.0.1',
    'port'=>3306,
    'name'=>'movcpc',
    'user'=>'movcpc',
    'pass'=>'redealtana158',
    'charset'=>'utf8mb4'
  ],
  'whatsapp'=>[
    'url'=>'',
    'token'=>''
  ]
];