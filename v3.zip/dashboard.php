<?php
require __DIR__ . '/lib/db.php'; require __DIR__ . '/lib/auth.php'; require_login();
$units = $pdo->query('SELECT id, unidade, COALESCE(capacidade, (SELECT COUNT(*) FROM beds WHERE beds.unidade_id=unidades.id)) AS capacidade FROM unidades ORDER BY id')->fetchAll();
include __DIR__ . '/includes/header.php';
?>
<h1>Dashboard - Ocupação</h1>
<div class="row"><?php foreach($units as $u):
    $total = (int)$u['capacidade'];
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM pacientes WHERE unidade = ? AND status = ?');
    $stmt->execute([$u['id'],'Internado']); $ocup = (int)$stmt->fetchColumn();
    $free = max(0, $total - $ocup); $pct = $total ? round($ocup/$total*100) : 0;
    $color = $pct>85 ? 'bg-danger' : ($pct>60 ? 'bg-warning text-dark' : 'bg-success');
?>
  <div class="col-md-4 mb-3"><div class="card"><div class="card-body"><h5 class="card-title"><?=htmlspecialchars($u['unidade'])?></h5>
    <p>Total leitos: <strong><?=$total?></strong> | Ocupados: <strong><?=$ocup?></strong> | Livres: <strong><?=$free?></strong></p>
    <div class="progress mb-2"><div class="progress-bar <?=$color?>" role="progressbar" style="width: <?=$pct?>%"><?=$pct?>%</div></div>
    <a class="btn btn-sm btn-primary" href="/pages/leitos.php?u=<?=intval($u['id'])?>">Ver leitos</a>
  </div></div></div>
<?php endforeach; ?></div>
<?php include __DIR__ . '/includes/footer.php'; ?>
